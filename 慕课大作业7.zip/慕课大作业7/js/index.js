// 获取元素
var getElem = function( selector ){
    return document.querySelector(selector);
}
var getAllElem = function( selector ){
    return document.querySelectorAll(selector);
}
var mainElem = {
    imooc:getElem(".imooc"),
    myMenu:getElem(".myMenu"),
    menu:getElem(".menu"),
    username:getElem("#username"),
    password:getElem("#password"),
    pwd:getAllElem(".pwd"),
    conPwd:getElem("#conPwd"),
    name:getElem("#name"),
    rule:getElem(".rule"),
    userId:getElem("#userId"),
    email:getElem("#email"),
    phone:getElem("#phone"),
    inputs:document.getElementsByTagName("input"),
    clause:getElem("#clause"),
    btn:getElem('#btn'),
    news:getAllElem(".new")
};
// 正则表达式
var pattern = {
    username:/^[a-zA-Z]\w{5,29}$/,
    password:/^\S{6,20}$/,
    conPwd:/^\S{6,20}$/,
    name:/^[\u4e00-\u9fa5]{2,15}$|^[a-zA-Z]{3,30}$/,
    userId:/^[1-9]{1}\d{16}(\d|[xX])$/,
    email:/^(?:\w+\.)*(\w+)@(?:\w+\.)+([a-zA-Z])+$/,
    phone:/^13\d{9}|147\d{8}$|15[0,1,2,3,5,6,7,8,9]{1}\d{8}$|18[0,2,5,6,7,8,9]{1}\d{8}$/
};
// 输入框为空或者输入文本错误时的提示文本
var error = [
    '6-30位字母、数字或“_”，字母开头',
    '6-20位，包括数字字母或符号',
    '密码不能为空',
    '姓名只能包含中文或英文，且字符在3-30个之间！',
    '请输入18位的身份证号码',
    '邮箱不能为空',
    '您输入的手机号码不是有效的格式'
];
// 输入正确时的文本
var correct = [
    '用户名输入正确',
    '',
    '两次输入一致',
    '姓名输入正确',
    '号码输入正确',
    '邮箱格式正确',
    '手机格式正确'
];
// mainElem.username.focus();
// 封装一个函数，判断输入的信息是否符合要求
function judge(ele,reg,idx){
    var newNews = mainElem.news[idx];
    if(reg.exec(ele.value)){
        newNews.innerHTML = correct[idx];
        newNews.style.color = "green";
        newNews.style.textDecoration = "none";
    }else{
        newNews.innerHTML = error[idx];
        newNews.style.color = "red";
        newNews.style.textDecoration = "none";
    }
}
// event对象跨浏览器兼容
var EventUtil = {
    addHandler: function(element, type, handler) {
        //绑定事件
        if(element.addEventListener) {
            element.addEventListener(type, handler, false);
        } else if(element.attachEvent) {
            element.attachEvent("on" + type, handler);
        } else {
            element["on" + type] = handler
        }
    }
}
// 给我的imooc添加事件
EventUtil.addHandler(mainElem.imooc,'mouseover',function(){
    mainElem.menu.style.display = "block";
    mainElem.myMenu.style.color = "rgb(251, 116, 3)"
})
EventUtil.addHandler(mainElem.imooc,'mouseout',function(){
    mainElem.menu.style.display = "none";
    mainElem.myMenu.style.color = "#000"
})
// 给姓名填写规则添加事件
EventUtil.addHandler(mainElem.news[3],'mouseover',function(){
    // 获取提示信息颜色来判断正误
    var color = this.style.color;
    if(color == "green"){
        mainElem.rule.style.display = "none";
    }else{
        mainElem.rule.style.display = "block";
    }
})
EventUtil.addHandler(mainElem.news[3],'mouseout',function(){
    mainElem.rule.style.display = "none";
})
// 密码强度等级的正则表达式
var rankLevel = {
    password_rank_a:/^\d{6,20}$|^[a-zA-Z]{6,20}$|^\W{6,20}$/,
    password_rank_b:/^[\d|a-zA-Z]{6,20}$|^[\W|a-zA-Z]{6,20}$|^[\d|\W]{6,20}$/,
    password_rank_c:/^[\W|\d|a-zA-Z]{6,20}$/
};
// 判断密码强度
function isPasswordLevel(){
    var pwdValue = mainElem.password.value;
    // 先判断是否输入框是否为空
    if(pwdValue ==''){
        mainElem.pwd[0].style.background = "#f00";
        mainElem.pwd[1].style.background = "#ddd";
        mainElem.pwd[2].style.background = "#ddd";
    }else if(pattern.password.test(pwdValue)){// 判断是否符合密码规则
        if(rankLevel.password_rank_a.test(pwdValue)){// 危险
            mainElem.pwd[0].style.background = "#f00";
            mainElem.pwd[1].style.background = "#ddd";
            mainElem.pwd[2].style.background = "#ddd";
        }else if(rankLevel.password_rank_b.test(pwdValue)){// 一般
            mainElem.pwd[0].style.background = "#f00";
            mainElem.pwd[1].style.background = "orange";
            mainElem.pwd[2].style.background = "#ddd";
        }else if(rankLevel.password_rank_c.test(pwdValue)){// 安全
            mainElem.pwd[0].style.background = "red";
            mainElem.pwd[1].style.background = "orange";
            mainElem.pwd[2].style.background = "green";
        }
    }
}
// 验证用户名是否符合要求  6-30位字母、数字或“_”，字母开头
EventUtil.addHandler(mainElem.username,'blur',function(){
    return judge(mainElem.username,pattern.username,0);
})
// 验证登录密码是否符合要求  6-20位，包括数字字母或符号，中间不能有空格
EventUtil.addHandler(mainElem.password,'blur',function(){
    isPasswordLevel();
    return judge(mainElem.password,pattern.password,1);
})
// 验证确认密码是否与登录密码一致
EventUtil.addHandler(mainElem.conPwd,'blur',function(){
    if(mainElem.password.value !=mainElem.conPwd.value){
        mainElem.news[2].innerHTML = "两次密码输入不一致，请重新输入";
        mainElem.news[2].style.color = "red"; 
    }else{
        return judge(mainElem.conPwd,pattern.conPwd,2);
    }
})
// 验证姓名是否符合要求
EventUtil.addHandler(mainElem.name,'blur',function(){
    return judge(mainElem.name,pattern.name,3);
})
// 验证身份证号码是否符合要求
EventUtil.addHandler(mainElem.userId,'blur',function(){
    return judge(mainElem.userId,pattern.userId,4);
})
// 验证邮箱是否符合要求
EventUtil.addHandler(mainElem.email,'blur',function(){
    return judge(mainElem.email,pattern.email,5);
})
// 验证手机号是否符合要求
EventUtil.addHandler(mainElem.phone,'blur',function(){
    return judge(mainElem.phone,pattern.phone,6);
})

var list = mainElem.inputs;
// 判断所有输入框是否都符合表达式
function allConfirm(){
    var isResult = true;
    for(var i = 0;i < list.length-1;i++){
        var str = list[i].value;
        var reg = pattern[list[i].id];
        isResult = isResult && reg.test(str);
    }
    return isResult;
}
// 给提交按钮绑定事件 
EventUtil.addHandler(mainElem.btn,'click',function(){
    // submit按钮有默认提交的行为，可以设置如下阻止默认行为
    event.preventDefault();
    if(allConfirm()){
        if(mainElem.clause.checked == true){
            window.location.href ="http://www.imooc.com";
        }
    }else{
        //遍历所有输入框，若不符合正则表达式，则显示错误文字
        for(var i=0;i<list.length-1;i++){
            var str = list[i].value;
            var reg = pattern[list[i].id];
            if(!reg.test(str)){
                mainElem.news[i].innerHTML = error[i];
                mainElem.news[i].style.color = "red";
            }
        }
        alert("请填写正确信息！");
    }
})
// EventUtil.addHandler(mainElem.btn,'mouseover',function(){
//     mainElem.btn.style.cursor = 'pointer';
//     mainElem.btn.style.boxShadow = '0px 0px 10px rgba(0,0,0,.5)';
// })
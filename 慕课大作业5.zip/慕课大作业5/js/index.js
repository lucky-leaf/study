window.onload=function(){  
    var index = 0,
        timer = null,//定时器
        main = byId("main"),
        li = byId("ul").getElementsByTagName("li"),
        pics = byId("banner").getElementsByTagName("div"),
        size = pics.length;
    function addHandler(element, type, handler) {
        if (element.addEventListener) {
            element.addEventListener(type, handler, false);
        }
        else if (element.attachEvent) {
            element.attachEvent('on' + type, handler);
        }
        else {
            element['on' + type] = handler;
        }
    }
    //封装getElementById
    function byId(id){
        return typeof(id)==="string"?document.getElementById(id):id;
    }   
    // 清除定时器,停止自动播放
    function stopAutoPlay(){
        if(timer){
            clearInterval(timer);
        }
    }
    // 图片自动轮播
    function startAutoPlay(){
        timer = setInterval(function(){
            index++;
            if(index >= size){
                index = 0;
            }
            changeImg();
        },1000)
    }
    // 封装切换图片
    function changeImg(){
        //遍历所有图片，将图片隐藏
        for(var i=0;i<size;i++){
            li[i].className = "";
            pics[i].style.display = "none";   
        }
        //显示当前图片
        li[index].className = "active";
        pics[index].style.display = "block";
    }
    //自动播放
    startAutoPlay();
    //鼠标滑入main停止轮播
    addHandler(main,"mouseover",stopAutoPlay);
    //鼠标划出main继续轮播
    addHandler(main,"mouseout",startAutoPlay);

    // 点击导航切换图片
    for(var i=0,len=li.length;i<len;i++){
        li[i].setAttribute("data-id",i)
        addHandler(li[i],'click',function(){
            index = this.getAttribute("data-id");
            changeImg();
        })
    }
}